import difflib
import logging
import google.generativeai as genai
from django.conf import settings
from abc import ABC, abstractmethod

logging.basicConfig(filename='acceso_seguro.log', level=logging.INFO, format='%(asctime)s - %(message)s')

class SistemaLog:
    _instancia = None
    def __new__(cls):
        if cls._instancia is None:
            cls._instancia = super(SistemaLog, cls).__new__(cls)
        return cls._instancia
    def registrar_evento(self, usuario, accion):
        mensaje = f"[AUDITORIA] Usuario: {usuario} - Accion: {accion}"
        logging.info(mensaje)
        print(mensaje) 

class EstrategiaBusqueda(ABC):
    @abstractmethod
    def buscar(self, query, queryset):
        pass

class BusquedaIADifusa(EstrategiaBusqueda):
    def buscar(self, query, queryset):
        resultados = []
        SistemaLog().registrar_evento("SISTEMA", f"Ejecutando IA para: {query}")
        for mascota in queryset:
            secuencia = difflib.SequenceMatcher(None, mascota.descripcion.lower(), query.lower())
            ratio = secuencia.ratio()
            if ratio > 0.4 or query.lower() in mascota.descripcion.lower():
                resultados.append(mascota)#me dae erroorrr
        return resultados

class FabricaMascotas:
    @staticmethod
    def crear_mascota(modelo_clase, datos):
        if len(datos['descripcion']) < 10:
            raise ValueError("La descripcion es muy corta. Minimo 10 caracteres.")
        nueva_mascota = modelo_clase(**datos)
        nueva_mascota.save()
        return nueva_mascota

class ChatbotIA:
    API_KEY = "AIzaSyBfDZ63niATgaXItcilwqqXt0q3BFBLd-4"
    
    @staticmethod
    def obtener_contexto_db(mensaje_usuario):
        from .models import Mascota
        todas = Mascota.objects.all()
        coincidencias = []
        for m in todas:
            if m.tipo.lower() in mensaje_usuario.lower() or m.zona.lower() in mensaje_usuario.lower() or m.nombre.lower() in mensaje_usuario.lower():
                coincidencias.append(f"- {m.nombre} ({m.tipo}) en {m.zona}: {m.descripcion}")
        return "\n".join(coincidencias[:5])

    @staticmethod
    def responder(mensaje_usuario):
        try:
            genai.configure(api_key=ChatbotIA.API_KEY)
            model = genai.GenerativeModel('gemini-1.5-flash') #gemini 2.5 no acepta y pide pago. queda en satndby 2 minutos al ser gratiss
            
            contexto_datos = ChatbotIA.obtener_contexto_db(mensaje_usuario)
            
            prompt_sistema = f"""
            Actua como el asistente virtual experto y empatico de la app Bienestar App.
            Tu mision es ayudar a encontrar mascotas perdidas y promover la adopcion.
            
            REGLAS STRICTAS:
            1. Solo responde temas de mascotas, seguridad y la app. Si te preguntan otra cosa, niegate educadamente.
            2. Usa la informacion de CONTEXTO DE DATOS para responder si aplica.
            3. Respuestas cortas (maximo 2 parrafos).
            
            CONTEXTO DE DATOS (Mascotas reales en base de datos):
            {contexto_datos}
            
            PREGUNTA DEL USUARIO:
            {mensaje_usuario}
            """
            
            response = model.generate_content(prompt_sistema)
            return response.text
            
        except Exception as e:
            print(f"Error Gemini: {e}")
            return ChatbotIA.responder_fallback(mensaje_usuario)

    @staticmethod
    def responder_fallback(mensaje):
        msg = mensaje.lower()
        palabras_clave = ["perro", "gato", "mascota", "animal", "perdido", "adopcion", "ayuda", "buscar"]

        if "hola" in msg:
            return "Hola, soy el asistente de Bienestar App. Aqui podras encontrar informacion sobre mascotas perdidas y en adopcion. Revisa nuestra lista principal para mas detalles."

        es_valido = False
        for p in palabras_clave:
            if p in msg:
                es_valido = True
                break
        
        if es_valido:#manejo de errores
            return "Para ver informacion detallada de las mascotas o reportar una extraviada por favor utiliza las opciones del menu principal de la aplicacion."
        else:
            return "Lo siento, no puedo ayudarte con ese tema. Solo respondo preguntas relacionadas con mascotas, animales y el funcionamiento de la app."